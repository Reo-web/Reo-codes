// Language type definition
export interface Language {
  code: string;
  name: string;
}

// Translation history item
export interface Translation {
  id: string;
  sourceLanguage: Language;
  targetLanguage: Language;
  originalText: string;
  translatedText: string;
  timestamp: Date;
  isFavorite: boolean;
}