import React from 'react';
import { Heart } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

const Footer = () => {
  const { theme } = useTheme();
  
  return (
    <footer className={`py-6 ${theme === 'dark' ? 'bg-gray-800 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>
      <div className="container mx-auto px-4 text-center text-sm">
        <div className="flex items-center justify-center mb-2">
          <span>Made with</span>
          <Heart className="h-4 w-4 mx-1 text-red-500 fill-current" />
          <span>for global communication</span>
        </div>
        <p>© {new Date().getFullYear()} LinguaBridge. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;