import React from 'react';
import type { Language } from '../types';
import { useTheme } from '../context/ThemeContext';

interface TranslationInputProps {
  value: string;
  onChange: (value: string) => void;
  language: Language;
}

const TranslationInput = ({ value, onChange, language }: TranslationInputProps) => {
  const { theme } = useTheme();
  
  return (
    <div className={`h-full rounded-lg border ${theme === 'dark' ? 'border-gray-700' : 'border-gray-300'}`}>
      <div className={`px-4 py-2 border-b ${theme === 'dark' ? 'border-gray-700 bg-gray-700/50' : 'border-gray-300 bg-gray-50'}`}>
        <span className="text-sm font-medium">
          {language.name}
        </span>
      </div>
      
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={`Type text in ${language.name}...`}
        className={`w-full h-40 p-4 resize-none focus:outline-none rounded-b-lg ${
          theme === 'dark' 
            ? 'bg-gray-800 text-white placeholder-gray-500' 
            : 'bg-white text-gray-900 placeholder-gray-400'
        }`}
      />
    </div>
  );
};

export default TranslationInput;