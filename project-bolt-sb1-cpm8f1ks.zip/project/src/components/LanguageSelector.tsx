import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import { languages } from '../data/languages';
import type { Language } from '../types';
import { useTheme } from '../context/ThemeContext';

interface LanguageSelectorProps {
  selectedLanguage: Language;
  onLanguageChange: (language: Language) => void;
  label?: string;
}

const LanguageSelector = ({ selectedLanguage, onLanguageChange, label }: LanguageSelectorProps) => {
  const { theme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const filteredLanguages = languages.filter(lang => 
    lang.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  return (
    <div className="relative w-full" ref={dropdownRef}>
      {label && (
        <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
          {label}
        </label>
      )}
      
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex items-center justify-between px-4 py-2 rounded-lg border ${
          theme === 'dark' 
            ? 'bg-gray-700 border-gray-600 text-white hover:bg-gray-600' 
            : 'bg-white border-gray-300 text-gray-900 hover:bg-gray-50'
        } transition-colors duration-200`}
      >
        <div className="flex items-center">
          <span className="font-medium">{selectedLanguage.name}</span>
        </div>
        <ChevronDown size={18} className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      {isOpen && (
        <div className={`absolute z-20 mt-1 w-full rounded-lg border shadow-lg ${
          theme === 'dark' 
            ? 'bg-gray-800 border-gray-700' 
            : 'bg-white border-gray-200'
        } max-h-60 overflow-auto`}>
          <div className={`sticky top-0 p-2 border-b ${theme === 'dark' ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'}`}>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search languages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full pl-10 pr-4 py-2 rounded-md ${
                  theme === 'dark' 
                    ? 'bg-gray-700 text-white placeholder-gray-400 border-gray-600' 
                    : 'bg-gray-50 text-gray-900 placeholder-gray-500 border-gray-300'
                } border focus:outline-none focus:ring-2 focus:ring-blue-500`}
              />
            </div>
          </div>
          
          <ul className="py-2">
            {filteredLanguages.length > 0 ? (
              filteredLanguages.map(language => (
                <li key={language.code}>
                  <button
                    onClick={() => {
                      onLanguageChange(language);
                      setIsOpen(false);
                      setSearchQuery('');
                    }}
                    className={`w-full text-left px-4 py-2 hover:bg-blue-50 dark:hover:bg-gray-700 ${
                      selectedLanguage.code === language.code 
                        ? 'bg-blue-50 text-blue-600 dark:bg-gray-700 dark:text-blue-400' 
                        : ''
                    }`}
                  >
                    {language.name}
                  </button>
                </li>
              ))
            ) : (
              <li className="px-4 py-2 text-gray-500 dark:text-gray-400">No languages found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;