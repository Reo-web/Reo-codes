import React, { useState, useEffect } from 'react';
import LanguageSelector from './LanguageSelector';
import TranslationInput from './TranslationInput';
import TranslationOutput from './TranslationOutput';
import TranslationControls from './TranslationControls';
import TranslationHistory from './TranslationHistory';
import { languages } from '../data/languages';
import { translate } from '../services/translationService';
import type { Translation, Language } from '../types';
import { useTheme } from '../context/ThemeContext';

const TranslatorContainer = () => {
  const { theme } = useTheme();
  const [sourceLanguage, setSourceLanguage] = useState<Language>(languages[0]);
  const [targetLanguage, setTargetLanguage] = useState<Language>(languages[1]);
  const [inputText, setInputText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [history, setHistory] = useState<Translation[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  
  const handleSwapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setInputText(translatedText);
    setTranslatedText(inputText);
  };
  
  useEffect(() => {
    const translateTimeout = setTimeout(() => {
      if (inputText.trim()) {
        setIsTranslating(true);
        translate(inputText, sourceLanguage.code, targetLanguage.code)
          .then(result => {
            setTranslatedText(result);
            
            if (inputText.trim() && result.trim()) {
              const newTranslation: Translation = {
                id: Date.now().toString(),
                sourceLanguage,
                targetLanguage,
                originalText: inputText,
                translatedText: result,
                timestamp: new Date(),
                isFavorite: false
              };
              
              setHistory(prev => [newTranslation, ...prev.slice(0, 19)]);
            }
          })
          .finally(() => {
            setIsTranslating(false);
          });
      } else {
        setTranslatedText('');
      }
    }, 500);
    
    return () => clearTimeout(translateTimeout);
  }, [inputText, sourceLanguage, targetLanguage]);
  
  const toggleFavorite = (id: string) => {
    setHistory(prev => 
      prev.map(item => 
        item.id === id ? { ...item, isFavorite: !item.isFavorite } : item
      )
    );
  };
  
  const removeFromHistory = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };
  
  const loadFromHistory = (translation: Translation) => {
    setSourceLanguage(translation.sourceLanguage);
    setTargetLanguage(translation.targetLanguage);
    setInputText(translation.originalText);
    setTranslatedText(translation.translatedText);
    setShowHistory(false);
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className={`mb-8 rounded-xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between mb-6">
            <h2 className="text-2xl font-bold mb-4 md:mb-0">
              <span className="text-blue-500">Translate</span> Anything
            </h2>
            
            <div className="flex space-x-4">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className={`px-4 py-2 rounded-lg font-medium ${
                  showHistory 
                    ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' 
                    : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                }`}
              >
                {showHistory ? 'Hide History' : 'Show History'}
              </button>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
            <LanguageSelector
              selectedLanguage={sourceLanguage}
              onLanguageChange={setSourceLanguage}
              label="Translate from"
            />
            
            <button
              onClick={handleSwapLanguages}
              className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'} transition-colors duration-200`}
              aria-label="Swap languages"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M7 16V4m0 0L3 8m4-4l4 4"></path>
                <path d="M17 8v12m0 0l4-4m-4 4l-4-4"></path>
              </svg>
            </button>
            
            <LanguageSelector
              selectedLanguage={targetLanguage}
              onLanguageChange={setTargetLanguage}
              label="Translate to"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TranslationInput
              value={inputText}
              onChange={setInputText}
              language={sourceLanguage}
            />
            
            <TranslationOutput
              value={translatedText}
              language={targetLanguage}
              isLoading={isTranslating}
            />
          </div>
          
          <TranslationControls
            onClear={() => setInputText('')}
            hasCameraOption={true}
            hasVoiceOption={true}
          />
        </div>
      </div>
      
      {showHistory && (
        <TranslationHistory
          translations={history}
          onToggleFavorite={toggleFavorite}
          onRemove={removeFromHistory}
          onSelect={loadFromHistory}
        />
      )}
    </div>
  );
};

export default TranslatorContainer;