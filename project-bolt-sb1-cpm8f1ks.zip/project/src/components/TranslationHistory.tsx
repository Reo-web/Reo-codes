import React from 'react';
import { Star, Trash2, Clock } from 'lucide-react';
import type { Translation } from '../types';
import { useTheme } from '../context/ThemeContext';

interface TranslationHistoryProps {
  translations: Translation[];
  onToggleFavorite: (id: string) => void;
  onRemove: (id: string) => void;
  onSelect: (translation: Translation) => void;
}

const TranslationHistory = ({ 
  translations, 
  onToggleFavorite, 
  onRemove, 
  onSelect 
}: TranslationHistoryProps) => {
  const { theme } = useTheme();
  
  // Format timestamp
  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
      day: 'numeric',
      month: 'short'
    }).format(date);
  };
  
  // Group translations by day
  const groupedTranslations = translations.reduce<{[key: string]: Translation[]}>((groups, translation) => {
    const date = new Date(translation.timestamp);
    const dateKey = date.toDateString();
    
    if (!groups[dateKey]) {
      groups[dateKey] = [];
    }
    
    groups[dateKey].push(translation);
    return groups;
  }, {});
  
  if (translations.length === 0) {
    return (
      <div className={`rounded-xl p-8 text-center ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
        <Clock className="mx-auto h-12 w-12 text-gray-400 mb-3" />
        <h3 className="text-lg font-medium mb-2">No translation history yet</h3>
        <p className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>
          Your recent translations will appear here
        </p>
      </div>
    );
  }
  
  return (
    <div className={`rounded-xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
      <div className="p-6">
        <h2 className="text-xl font-bold mb-4">
          <span className="text-blue-500">Recent</span> Translations
        </h2>
        
        <div className="space-y-6">
          {Object.entries(groupedTranslations).map(([dateKey, items]) => (
            <div key={dateKey}>
              <h3 className={`text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {new Date(dateKey).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
              </h3>
              
              <div className="space-y-2">
                {items.map(translation => (
                  <div 
                    key={translation.id} 
                    className={`p-4 rounded-lg border ${
                      theme === 'dark' 
                        ? 'border-gray-700 hover:bg-gray-700' 
                        : 'border-gray-200 hover:bg-gray-50'
                    } transition-colors duration-200 cursor-pointer group`}
                    onClick={() => onSelect(translation)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium">
                          {translation.sourceLanguage.name} → {translation.targetLanguage.name}
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleFavorite(translation.id);
                          }}
                          className={`p-1 rounded-full ${
                            theme === 'dark' 
                              ? 'hover:bg-gray-600' 
                              : 'hover:bg-gray-200'
                          }`}
                          aria-label={translation.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                        >
                          <Star 
                            size={16} 
                            className={translation.isFavorite ? 'text-yellow-400 fill-current' : 'text-gray-400'} 
                          />
                        </button>
                        
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onRemove(translation.id);
                          }}
                          className={`p-1 rounded-full ${
                            theme === 'dark' 
                              ? 'hover:bg-gray-600 text-gray-400 hover:text-red-400' 
                              : 'hover:bg-gray-200 text-gray-500 hover:text-red-500'
                          }`}
                          aria-label="Remove from history"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <div>
                        <p className="text-sm truncate">{translation.originalText}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm truncate">{translation.translatedText}</p>
                      </div>
                    </div>
                    
                    <div className="mt-2 flex justify-end">
                      <span className={`text-xs ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
                        {formatTime(new Date(translation.timestamp))}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TranslationHistory;