import React from 'react';
import { Copy, Volume2 } from 'lucide-react';
import type { Language } from '../types';
import { useTheme } from '../context/ThemeContext';

interface TranslationOutputProps {
  value: string;
  language: Language;
  isLoading: boolean;
}

const TranslationOutput = ({ value, language, isLoading }: TranslationOutputProps) => {
  const { theme } = useTheme();
  
  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    // Could add a toast notification here
  };
  
  const handleSpeak = () => {
    const utterance = new SpeechSynthesisUtterance(value);
    // Try to find a voice that matches the language
    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find(v => v.lang.startsWith(language.code));
    if (voice) {
      utterance.voice = voice;
    }
    window.speechSynthesis.speak(utterance);
  };
  
  return (
    <div className={`h-full rounded-lg border ${theme === 'dark' ? 'border-gray-700' : 'border-gray-300'}`}>
      <div className={`px-4 py-2 border-b flex justify-between items-center ${
        theme === 'dark' ? 'border-gray-700 bg-gray-700/50' : 'border-gray-300 bg-gray-50'
      }`}>
        <span className="text-sm font-medium">
          {language.name}
        </span>
        
        {value && (
          <div className="flex space-x-2">
            <button
              onClick={handleSpeak}
              className={`p-1 rounded-full ${
                theme === 'dark' 
                  ? 'hover:bg-gray-600 text-gray-300' 
                  : 'hover:bg-gray-200 text-gray-600'
              }`}
              aria-label="Speak translation"
              title="Speak translation"
            >
              <Volume2 size={16} />
            </button>
            
            <button
              onClick={handleCopy}
              className={`p-1 rounded-full ${
                theme === 'dark' 
                  ? 'hover:bg-gray-600 text-gray-300' 
                  : 'hover:bg-gray-200 text-gray-600'
              }`}
              aria-label="Copy to clipboard"
              title="Copy to clipboard"
            >
              <Copy size={16} />
            </button>
          </div>
        )}
      </div>
      
      <div className={`w-full h-40 p-4 rounded-b-lg overflow-auto ${
        theme === 'dark' 
          ? 'bg-gray-800 text-white' 
          : 'bg-white text-gray-900'
      }`}>
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-pulse flex space-x-2">
              <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
              <div className="h-2 w-2 bg-blue-500 rounded-full animation-delay-200"></div>
              <div className="h-2 w-2 bg-blue-500 rounded-full animation-delay-400"></div>
            </div>
          </div>
        ) : value ? (
          <p>{value}</p>
        ) : (
          <p className={`italic ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
            Translation will appear here...
          </p>
        )}
      </div>
    </div>
  );
};

export default TranslationOutput;