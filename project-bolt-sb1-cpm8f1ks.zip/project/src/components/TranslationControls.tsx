import React, { useState } from 'react';
import { Mic, Camera, X, Check } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface TranslationControlsProps {
  onClear: () => void;
  hasVoiceOption: boolean;
  hasCameraOption: boolean;
}

const TranslationControls = ({ onClear, hasVoiceOption, hasCameraOption }: TranslationControlsProps) => {
  const { theme } = useTheme();
  const [isListening, setIsListening] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  
  // Voice input simulation
  const handleVoiceInput = () => {
    setIsListening(!isListening);
    
    // Simulate voice recognition
    if (!isListening) {
      setTimeout(() => {
        setIsListening(false);
        // In a real app, we would add the recognized text to the input
      }, 3000);
    }
  };
  
  // Camera input simulation
  const handleCameraInput = () => {
    setIsCameraActive(!isCameraActive);
    
    // Simulate camera processing
    if (!isCameraActive) {
      setTimeout(() => {
        setIsCameraActive(false);
        // In a real app, we would add the recognized text to the input
      }, 3000);
    }
  };
  
  return (
    <div className="flex items-center justify-between mt-4">
      <div className="flex space-x-2">
        {hasVoiceOption && (
          <button
            onClick={handleVoiceInput}
            className={`p-2 rounded-full ${
              isListening
                ? 'bg-red-500 text-white'
                : theme === 'dark'
                  ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            } transition-colors duration-200`}
            aria-label={isListening ? 'Stop listening' : 'Voice input'}
            title={isListening ? 'Stop listening' : 'Voice input'}
          >
            {isListening ? <Check size={18} /> : <Mic size={18} />}
          </button>
        )}
        
        {hasCameraOption && (
          <button
            onClick={handleCameraInput}
            className={`p-2 rounded-full ${
              isCameraActive
                ? 'bg-red-500 text-white'
                : theme === 'dark'
                  ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            } transition-colors duration-200`}
            aria-label={isCameraActive ? 'Cancel camera' : 'Camera input'}
            title={isCameraActive ? 'Cancel camera' : 'Camera input'}
          >
            {isCameraActive ? <X size={18} /> : <Camera size={18} />}
          </button>
        )}
      </div>
      
      <button
        onClick={onClear}
        className={`px-3 py-1 text-sm rounded ${
          theme === 'dark'
            ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        } transition-colors duration-200`}
      >
        Clear
      </button>
    </div>
  );
};

export default TranslationControls;