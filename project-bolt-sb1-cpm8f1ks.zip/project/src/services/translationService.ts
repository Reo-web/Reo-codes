import axios from 'axios';

const LIBRETRANSLATE_API = 'https://libretranslate.de/translate';

export const translate = async (
  text: string,
  sourceLanguage: string,
  targetLanguage: string
): Promise<string> => {
  if (!text.trim()) {
    return '';
  }

  try {
    const response = await axios.post(LIBRETRANSLATE_API, {
      q: text,
      source: sourceLanguage,
      target: targetLanguage,
    });

    return response.data.translatedText;
  } catch (error) {
    console.error('Translation error:', error);
    // Fallback to mock translation if API fails
    return mockTranslate(text, sourceLanguage, targetLanguage);
  }
};

// Keep the mock translate as fallback
export const mockTranslate = async (
  text: string,
  sourceLanguage: string,
  targetLanguage: string
): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 500));
  
  if (!text.trim()) {
    return '';
  }
  
  const translations: { [key: string]: (text: string) => string } = {
    en: (text) => text,
    ko: (text) => {
      const koreanized = text
        .replace(/is/g, '이에요')
        .replace(/the/g, '그')
        .replace(/\./g, '요.');
      return `${koreanized} - 한국어`;
    },
    ja: (text) => {
      const japanized = text
        .replace(/is/g, 'です')
        .replace(/the/g, 'その')
        .replace(/\./g, 'ます。');
      return `${japanized} - 日本語`;
    },
    es: (text) => `¡${text.replace(/the/g, 'el').replace(/is/g, 'es')}!`,
    fr: (text) => `${text.replace(/the/g, 'le').replace(/is/g, 'est')} - en français`,
    de: (text) => `${text.replace(/the/g, 'die').replace(/is/g, 'ist')} - auf Deutsch`,
    it: (text) => `${text.replace(/the/g, 'il').replace(/is/g, 'è')} - in italiano`,
    pt: (text) => `${text.replace(/the/g, 'o').replace(/is/g, 'é')} - em português`,
    ru: (text) => `${text} - на русском`,
    zh: (text) => `${text} - 用中文`,
    ar: (text) => `${text} - بالعربية`,
    hi: (text) => `${text} - हिंदी में`,
  };
  
  if (translations[targetLanguage]) {
    return translations[targetLanguage](text);
  }
  
  return `[${targetLanguage.toUpperCase()}] ${text}`;
};

export const detectLanguage = async (text: string): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  
  if (/[\u3130-\u318F\uAC00-\uD7AF]/.test(text)) return 'ko';
  if (/[\u3040-\u309F\u30A0-\u30FF]/.test(text)) return 'ja';
  if (/[\u4E00-\u9FAF]/.test(text)) {
    if (/[\u3040-\u309F\u30A0-\u30FF]/.test(text)) return 'ja';
    return 'zh';
  }
  if (/[\u0600-\u06FF]/.test(text)) return 'ar';
  if (/[\u0900-\u097F]/.test(text)) return 'hi';
  
  if (/[ñáéíóúü]/i.test(text)) return 'es';
  if (/[àâçéèêëîïôùûüÿ]/i.test(text)) return 'fr';
  if (/[äöüß]/i.test(text)) return 'de';
  if (/[àèéìíòóù]/i.test(text)) return 'it';
  
  return 'en';
};

export const getSuggestions = async (
  text: string,
  sourceLanguage: string,
  targetLanguage: string
): Promise<string[]> => {
  await new Promise(resolve => setTimeout(resolve, 200));
  
  const commonPhrases: { [key: string]: string[] } = {
    greetings: [
      'Hello (안녕하세요 / こんにちは)',
      'Thank you (감사합니다 / ありがとうございます)',
      'Nice to meet you (만나서 반갑습니다 / はじめまして)'
    ],
    travel: [
      'Where is this place? (이 곳이 어디입니까? / この場所はどこですか?)',
      'How much is it? (얼마입니까? / いくらですか?)',
      'I need help (도움이 필요합니다 / 助けが必要です)'
    ],
    food: [
      'This is delicious (맛있습니다 / おいしいです)',
      'Can I have the menu? (메뉴 좀 주세요 / メニューをください)',
      'I am vegetarian (저는 채식주의자입니다 / ベジタリアンです)'
    ],
    business: [
      'Nice to work with you (함께 일하게 되어 기쁩니다 / 一緒に働けて嬉しいです)',
      'Please explain again (다시 설명해 주세요 / もう一度説明してください)',
      'I understand (알겠습니다 / 分かりました)'
    ]
  };
  
  let category = 'greetings';
  
  if (/where|location|place|hotel|stay|taxi/i.test(text)) {
    category = 'travel';
  } else if (/food|eat|restaurant|menu|hungry|drink/i.test(text)) {
    category = 'food';
  } else if (/work|business|meeting|project|team/i.test(text)) {
    category = 'business';
  }
  
  return commonPhrases[category]
    .sort(() => 0.5 - Math.random())
    .slice(0, 3);
};