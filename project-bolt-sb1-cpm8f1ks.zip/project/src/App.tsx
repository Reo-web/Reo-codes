import React from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Layout from './components/Layout';
import TranslatorContainer from './components/TranslatorContainer';

function App() {
  return (
    <ThemeProvider>
      <Layout>
        <TranslatorContainer />
      </Layout>
    </ThemeProvider>
  );
}

export default App;